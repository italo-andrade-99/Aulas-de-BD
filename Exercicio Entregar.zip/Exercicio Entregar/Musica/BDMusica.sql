create database Musica;

use Musica;

create table tbl_musica (
id_musica int primary key auto_increment,
nome_musica varchar (50),
artista varchar (40),
genero varchar (50)
);

create table album(
id_album int primary key auto_increment,
nome_album varchar (40),
gravadora varchar (40)
);

insert into tbl_musica values 
(null,'California', 'lana del rey', 'sadboy girl'),
(null,'ticket','maroom 5', 'pop'),
(null,'michael jackson', 'pire','pop');

insert into album values 
(null,'Love seilaoq', 'Panine'),
(null,'Sousei', 'Marvel'),
(null,'Alola','Chama');

alter table tbl_musica add column fk_album int; 
describe tbl_musica;
alter table tbl_musica add foreign key (fk_album) references album(id_album);

update tbl_musica set fk_album = 1 where id_musica = 1;
update tbl_musica set fk_album = 2 where id_musica = 2;
update tbl_musica set fk_album = 3 where id_musica = 3;    

select * from tbl_musica;

select * from tbl_musica,album where fk_album = id_album and nome_album = 'alola';

select * from tbl_musica,album where fk_album = id_album and gravadora = 'Panine';
